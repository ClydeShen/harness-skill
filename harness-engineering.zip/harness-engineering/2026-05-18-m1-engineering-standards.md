# M1 Engineering Standards & Harness Setup
**Date:** 2026-05-18
**Status:** Approved
**Scope:** Code quality standards, process standards, stability gates, and Claude Code harness configuration for M1 development

---

## 1. Code Quality Standards

### TypeScript (`tsconfig.json`)

```json
{
  "compilerOptions": {
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "exactOptionalPropertyTypes": true
  }
}
```

- No `any` — use `unknown` at system boundaries (external API responses, user input)
- Prisma-generated types are the DB source of truth; never redeclare model types manually

### ESLint

Base: `next/core-web-vitals` (built-in) + `@typescript-eslint/recommended`

Additional rules enforced:
```json
{
  "rules": {
    "no-console": "warn",
    "@typescript-eslint/no-explicit-any": "error"
  }
}
```

### Naming Conventions

| Thing | Convention |
|-------|------------|
| React component files | `PascalCase.tsx` |
| lib / util files | `camelCase.ts` |
| API route files | `route.ts` (Next.js fixed) |
| Test files | `__tests__/*.test.ts` |
| Variables / functions | `camelCase` |
| Types / interfaces | `PascalCase` |
| Env vars | `SCREAMING_SNAKE_CASE` |

### API Response Shape

Every `route.ts` handler returns exactly one of:
- `{ data: T }` on success (HTTP 200 / 201)
- `{ error: string }` on failure (HTTP 400)
- HTTP 401 — unauthenticated (no body)
- HTTP 403 — forbidden (no body)
- HTTP 404 — not found (no body)

No bare responses. No non-standard shapes.

### File Size Signal

200 lines soft limit per file. Not a linter rule — a signal to decompose if exceeded.

---

## 2. Process Standards

### Branch Naming

```
feat/<slug>    new feature
fix/<slug>     bug fix
chore/<slug>   tooling, config, cleanup
```

Every `feat/*` branch gets an isolated git worktree via the `using-git-worktrees` skill. Main worktree stays on `main` at all times.

### Commit Message Format — Conventional Commits

Full specification: https://www.conventionalcommits.org/en/v1.0.0/

```
<type>(<scope>): <description>

[body — WHY, not what; required when reason is non-obvious]

[footer(s)]
```

**Scope is required.** Maps to the architecture layer being changed:

| Scope | Maps to |
|-------|---------|
| `editor` | `components/editor/`, `lib/editor/` |
| `template` | `lib/template/` |
| `auth` | `auth.ts`, `app/api/auth/` |
| `db` | `lib/db/`, `prisma/schema.prisma` |
| `storage` | `lib/storage/` |
| `ai` | `lib/ai/` |
| `assets` | `lib/assets/`, `components/assets/` |
| `gamedata` | `lib/gamedata/`, `components/game-data/` |
| `export` | `lib/export/`, `components/export/` |
| `infra` | `infra/` |
| `config` | `next.config.ts`, `tsconfig.json`, `.github/`, Husky |

**Types:** `feat` · `fix` · `docs` · `chore` · `refactor` · `test` · `ci` · `perf`

**Breaking changes** — two required signals when a DB schema change, API contract change, or public interface changes:
```
feat(db)!: add componentType to Layout

BREAKING CHANGE: prisma db push required before app restart
```

**Examples:**
```
feat(editor): add Zone drag-to-move on tldraw canvas
fix(auth): redirect to login on expired Better Auth session
chore(config): add PostToolUse eslint hook to .claude/settings.json
docs(spec): add harness engineering standards
refactor(template): extract Zone type helpers into zone.ts
```

Body is required when the reason is not obvious from the description alone.

### Definition of Done (per task)

- `npm run build` exits 0
- `npm run lint` exits 0
- No new `any` types introduced
- All API handlers follow `{ data }` / `{ error }` shape
- Relevant spec in `docs/superpowers/specs/` exists and was written before code

---

## 3. Stability Gates

### Pre-commit (Husky + lint-staged)

Two steps on every `git commit`:

```
Step 1 — lint-staged (per staged *.{ts,tsx} file):
  eslint --fix
  prettier --write

Step 2 — tsc (whole project):
  tsc --noEmit
```

`tsc --noEmit` runs on the full project — TypeScript requires cross-file context. Target: pre-commit completes in under 15 seconds.

**Config files:**
- `.husky/pre-commit`
- `.lintstagedrc.json`
- `prettier.config.js`

**Escape hatch:** `git commit --no-verify` is allowed only for WIP commits to a feature branch, never directly to `main`.

### CI — GitHub Actions

`.github/workflows/ci.yml` — triggers on push to `main`:

```yaml
name: CI
on:
  push:
    branches: [main]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      - run: npm ci
      - run: npm run lint
      - run: npm run build
```

No test job scaffolded empty — tests are added to CI as they are written.

### What Each Gate Catches

| Gate | Catches |
|------|---------|
| lint-staged ESLint | style violations in staged files; auto-fixes trivial ones |
| pre-commit `tsc` | cross-file type errors before commit |
| CI lint | anything `--fix` silently masked |
| CI build | import errors, missing modules, Next.js build-time failures |

---

## 4. Claude Code Harness

### Hooks

Two hooks are configured. Together they close the verification loop mechanically — no relying on Claude remembering to verify.

`.claude/settings.json` (project-level):
```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          {
            "type": "command",
            "command": "npx eslint --fix \"$CLAUDE_FILE_PATH\""
          }
        ]
      }
    ],
    "Stop": [
      {
        "hooks": [
          {
            "type": "prompt",
            "prompt": "Before ending this turn: have you run npm run build and npm run lint? If this was UI work, have you opened the feature in a browser? If any check is outstanding, complete it now."
          }
        ]
      }
    ]
  }
}
```

| Hook | Trigger | Purpose |
|---|---|---|
| `PostToolUse` (Edit\|Write) | After every file edit | Auto-run `eslint --fix` — Claude never manually lints |
| `Stop` | End of every turn | Nudge Claude to verify before declaring done — machine-enforced Verification Gap |

### Permission Allowlist

| Tier | Commands |
|------|----------|
| **Auto-approve** | `npm run dev/build/lint`, `git status/diff/log/add/commit`, `npx tsc --noEmit`, `npx prisma db push`, `npx prisma studio`, `supabase start/stop/status`, `terraform plan`, standard file reads |
| **Always prompt** | `git push`, `git reset --hard`, `git branch -D`, `terraform apply`, `rm -rf` |
| **Default** | Everything else — prompt once, remember per session |

### CLAUDE.md Quality Contract

CLAUDE.md is the primary context anchor — always in context. `DESIGN.md` is its UI/UX counterpart — read before any UI work.

**Instruction budget:** Frontier LLMs reliably follow ~150–200 instructions. Claude Code's built-in system prompt consumes ~50, leaving a budget of ~100–150 for CLAUDE.md. Every line spent on something non-universal crowds out something that matters. Target 60 lines; 200 is the hard ceiling.

**Progressive disclosure hierarchy** — agent navigates on-demand, not encyclopedic upfront loading:
```
CLAUDE.md                always loaded — operating manual, boundaries, skill triggers
DESIGN.md                read before UI work — visual language harness
docs/superpowers/specs/  read when implementing a specific feature
docs/ARCHITECTURE.md     read when making architectural decisions
```

Rules:
- **60 lines ideal, 200 hard max** — every line over 60 degrades all rules uniformly
- **Universal applicability only** — task-specific guidance goes into `/commands` or `docs/`; one-off instructions are never added
- **Never send an LLM to do a linter's job** — code style rules belong in ESLint/Prettier config, not CLAUDE.md prose
- **File:line pointers** over code snippets — snippets go stale; pointers stay current
- Contains: tech stack, key commands, gotchas, architecture hard boundaries, skill trigger reminders
- References `docs/` for deep specs — never duplicates them inline
- Updated at session end via `/claude-md-management:revise-claude-md`
- Never contains: resolved bugs, session-specific state, ephemeral decisions, code patterns, style rules

**Conditional rules with `<important if>` tags:**

For task-specific rules that must not be dismissed as CLAUDE.md grows, wrap them with an explicit condition:
```markdown
<important if="you are writing or modifying tests">
- Use the project's test factory helpers, not raw fixtures
- Run npm run test before marking the task done
</important>

<important if="you are editing a route handler in app/api/">
- Auth check must be the first operation
- DB queries only via lib/db/[model].ts — never prisma.* directly
</important>
```

Rules:
- Conditions must be **narrow and specific** ("writing or modifying tests"), never broad ("writing code")
- Do **not** wrap foundational content (tech stack, directory structure) — these are always applicable
- The `if` condition gives Claude a clear signal for when to apply the rule, preventing premature dismissal

### Skills as Workflow Gates

See §5 for the canonical table including UI/UX gates. Skipping skills is the primary source of wasted work — they are not optional.

### Skill Writing Rules

When writing or updating a skill's `SKILL.md`:

| Rule | Detail |
|---|---|
| **Description = trigger condition** | "When should I fire?" not "What does this do?" — the description is how Claude decides to invoke the skill |
| **Gotchas section is mandatory** | Only real failure points that surprised you; never state the obvious |
| **Goals and constraints, not prescriptions** | Tell the skill what to achieve and what to avoid; don't railroad with step-by-step instructions |
| **No obvious statements** | If a senior engineer would say "of course", cut it |
| **`context: fork`** | For skills that should run in an isolated subagent, add `context: fork` to the frontmatter |

```markdown
---
name: my-skill
description: Use when the user is about to modify a route handler — fires on "edit route", "add endpoint", "API change"
context: fork   # optional: run in isolated subagent
---

## Gotchas
- Auth check must come before any DB call — missing this has caused 401 bypasses before
- prisma.* calls are forbidden in route handlers; always use lib/db/

## Goal
Produce a route handler that passes auth check, delegates DB work to lib/db/, and returns {data} or {error}.
```

### Session Lifecycle Protocol

Every Claude Code session follows three explicit phases. **If the repository is not in a known-good state, stop and fix it before starting work.**

Reference: [walkinglabs/learn-harness-engineering](https://github.com/walkinglabs/learn-harness-engineering) — Five core subsystems: Instructions · State · Verification · Scope · Session Lifecycle

**Phase 1 — Init (before any work)**
```
1. Run init.sh            → validates environment health
2. Read MEMORY.md         → load cross-session context
3. git status             → confirm clean working tree or known WIP
4. Verify baseline        → npm run build + npm run lint must pass before touching anything;
                            if they don't, fix the baseline first — never start on a broken base
5. Read relevant spec     → the one being implemented, not all docs/
6. Create/resume tasks    → TaskCreate for new work; TaskUpdate in_progress
7. Initial interview      → for any task > ~1 hour: surface context, constraints,
                            bad outcomes, and unknowns before writing a single line
                            of code (see "Initial Interview" below)
```

**Phase 2 — Execute (one feature at a time)**
- One task `in_progress` at a time — no task-switching mid-feature
- Follow skill gates from §5 table: brainstorm → plan → implement → verify
- Commit after each meaningful unit of work — small, scoped, traceable commits

**Phase 3 — Wrap-up (before ending session)**
```
1. npm run build          → confirm build still passes
2. git status             → no unintentional unstaged changes
3. TaskUpdate completed   → mark tasks done
4. Save memobank          → new learnings, decisions, feedback
5. /claude-md-management:revise-claude-md  → update CLAUDE.md if needed
```

### Initial Interview

Before any task that will run autonomously for more than ~1 hour, Claude must surface and resolve unknowns with the user. This is not optional — skipping it is the primary cause of multi-hour wasted runs.

The interview covers six areas:

1. **Full project context** — what is the goal of this work within the broader system?
2. **What bad looks like** — what outcomes would be a disaster? (data loss, breaking auth, shipping broken UI, etc.)
3. **Prior attempts and traps** — what has already been tried? what has gone wrong before?
4. **Common missed bugs** — what are the gotchas specific to this area of the codebase?
5. **Open questions** — end with: *"Before I start, do you have any questions or constraints I should know about?"*
6. **Sprint Contract** — before the first line of code, agree on the exact done criteria: which specific files will change, which commands prove it works, which user-visible behaviour confirms completion. This is not the same as writing a spec — it is negotiating a verifiable finish line.

Only start coding after the user says go. The interview is the alignment gate.

The Sprint Contract prevents the most common failure: work that looks done but isn't, because "done" was never defined precisely enough to be testable.

### Goal Structure (GoalBuddy)

For any task that will run autonomously for more than ~1 hour, use GoalBuddy to create a structured goal board before executing.

```bash
# Install once (already done if this spec was followed)
npx goalbuddy

# Prepare a goal board — interactive intake, creates docs/goals/<slug>/
/goal-prep

# Execute the board
/goal Follow docs/goals/<slug>/goal.md.
```

**Do not use GoalBuddy for a one-change task.** `TaskCreate` is sufficient. GoalBuddy is for multi-step, multi-session, or ambiguous work where the AI must discover, sequence, and verify its own tasks.

#### The Four Primitives

| Primitive | File | Who owns it |
|---|---|---|
| **Charter** | `docs/goals/<slug>/goal.md` | Human-editable; describes what the tranche is trying to accomplish |
| **Board** | `docs/goals/<slug>/state.yaml` | Machine truth; wins if charter and board conflict |
| **Task** | one entry in `state.yaml` | Exactly one active task at a time |
| **Receipt** | inline on the task card (or `notes/<id>.md`) | Compact durable proof that the task happened |

#### Intake Fields (required in `goal.md`)

| Field | Question it answers |
|---|---|
| **Objective** | What specific outcome must become true? |
| **Non-Negotiable Constraints** | What must not be changed or broken? |
| **Completion Proof** | Observable signal that proves the full outcome is done — not a proxy signal |
| **Likely Misfire** | How could the AI succeed at the wrong thing? Force this question. |
| **Stop Rule** | Stop only when a final Judge/PM audit receipt says `full_outcome_complete: true` |

#### Scout / Judge / Worker Roles

| Role | Write access | Use for |
|---|---|---|
| **Scout** | None — read only | Mapping repo, finding evidence, identifying candidates |
| **Judge** | None — read only | Choosing next slice, reviewing completed slices, final audit |
| **Worker** | Only inside `allowed_files` | Executing one coherent bounded slice; leaves receipt with `changed_files` + `verify` commands |
| **PM** | Control files only | Owning the board; choosing active tasks; updating `state.yaml` |

No implementation without an active Worker task that explicitly names `allowed_files`. Judge decides; Worker executes; Judge does not implement.

#### Slice Sizing

A good task is the **largest safe useful slice** — not the smallest safe task. Safe means: bounded, explicit, verified, reversible. A Worker task should produce a working screen, working API path, working vertical slice, or real bug fix. Two consecutive tiny tasks with no behaviour change = board needs reorientation.

#### Continuation Rule

After a task completes, immediately select the next active task unless a final Judge audit proves `full_outcome_complete: true`. Do not stop at "plan ready", "Scout done", or "one Worker verified". Keep advancing safe work until the full original outcome is complete.

**Blocked ≠ Stop.** When a task is blocked (missing credentials, needs owner decision, requires destructive action), mark that specific task blocked with a receipt, create the smallest safe follow-up, and continue all local non-destructive work. Set `goal.status: blocked` only when no safe local work remains.

**Fuzzy goals cause two failure modes:**
- **Lazy exit** — AI finds a plausible-looking stopping point and declares victory
- **Spiral** — AI has no valid stopping condition and loops endlessly

If `Completion Proof` and `Stop Rule` cannot be filled in before starting, the task is not ready to execute.

**Proxy signals are not stopping conditions.** "Compile passes" and "one test passes" are proxy signals. Completion requires a Judge or PM audit receipt with `full_outcome_complete: true` mapping back to the original user outcome and real implementation evidence.

### Verification Gap

> "Agents declare victory prematurely based on confidence rather than evidence." — learn-harness-engineering

The verification gap is the most common failure mode. A task is not done until:
- `npm run build` exits 0 — not just "I think the types are correct"
- `npm run lint` exits 0 — not just "I fixed the obvious issues"
- Feature is seen running in a browser (for UI work) — not just "the code looks right"
- The specific DoD checklist from §2 is checked line by line — every item, not a scan

**Anti-patterns that mask the gap:**

| Anti-pattern | What it looks like | Why it fails |
|---|---|---|
| Fuzzy Done | "Fix all the bugs" · "Improve UX" | Unquantifiable; AI exits at first plausible-looking state |
| Proxy Signal | "Compile passes" · "One test passes" | Compile and one test passing ≠ feature working; real validation still required |
| Planning = Done | "Plan is ready" · "Scout/Judge complete" | Planning is not completion; implementation evidence + Judge audit required |
| Confidence-based exit | "I believe this is correct" | Belief is not evidence; run the build, open the browser |

`verification-before-completion` skill enforces this. It is non-negotiable.

### Mission Pattern (multi-session tasks)

For tasks that span multiple sessions or require waiting for external feedback (e.g., waiting for a deploy to propagate, waiting for test results, waiting for market signals):

**Do not run a continuous loop.** Instead:

1. Write a `mission.md` note (or task description) capturing: current hypothesis, what was just tried, what artifact was produced, what to check next session
2. Execute exactly one step: hypothesis → action → artifact
3. Suspend — end the session, do not spin-wait
4. Schedule the next check (`ScheduleWakeup`) matched to how fast the state changes — not as a round number, not as a short poll

**Human escalation gate:** If the next step would require a dramatic change (architecture change, data deletion, breaking a contract) or if the mission's success cannot be objectively verified, stop and surface to the user. Do not proceed autonomously past a point where the user cannot easily undo the action.

Tasks that require external feedback to validate (real user traffic, market response, multi-day A/B tests) are **not suitable** for autonomous Goal loops. A judge model without access to real feedback data will produce fabricated confidence scores and waste tokens. Use Mission pattern + human review instead.

### `init.sh` — Environment Health Check

`init.sh` at the project root. Run at the start of every session. Exits non-zero if any check fails.

```bash
#!/usr/bin/env bash
set -e

echo "=== Environment Health Check ==="

# Node version
node_version=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
[ "$node_version" -ge 20 ] || { echo "ERROR: Node.js >= 20 required"; exit 1; }
echo "✓ Node.js $(node -v)"

# .env.local exists
[ -f ".env.local" ] || { echo "ERROR: .env.local missing — copy from .env.example"; exit 1; }
echo "✓ .env.local present"

# Docker running (required for supabase start)
docker info > /dev/null 2>&1 || { echo "ERROR: Docker not running"; exit 1; }
echo "✓ Docker running"

# TypeScript clean
npx tsc --noEmit && echo "✓ TypeScript clean" || { echo "ERROR: Type errors present"; exit 1; }

echo "=== Ready ==="
```

### Worktree Workflow

```
main worktree     → always clean, always on main
feat/* worktrees  → isolated per task, created via using-git-worktrees
                    deleted after merge to main
```

Merge directly to main (no PR review step). CI runs on push to main as the final gate.

### Memory Management (memobank)

- **Session start**: read `MEMORY.md` index; load relevant memories before any work
- **Session end**: save new learnings — user preferences, project decisions, validated approaches, corrected mistakes
- **Types to save**: `user` (profile), `feedback` (corrections + validations), `project` (decisions + context), `reference` (where things live)
- **Never save**: code patterns (in the code), debugging solutions (in commit messages), ephemeral session state

### Context Window Management

**Degradation zones — act before reaching them, not after:**

| Context usage | State | Action |
|---|---|---|
| < 30% | Healthy | Continue normally |
| 30–40% | Warning | Offload expensive work (searches, analysis) to subagents; avoid loading large files |
| **40%+** | **Degradation zone** | Intelligence measurably drops here; `/compact` now or delegate to subagent |
| > 60% | Simple tasks only | For any high-stakes or complex next step: `/clear` + structured handoff file |

**`/compact` vs Context Reset — choose deliberately:**

| | `/compact` | Context Reset (`/clear` + handoff) |
|---|---|---|
| **Cost** | Lower — stays in session | Higher — fresh context load |
| **Fidelity** | Lossy — summarises history | Full — structured handoff file captures all state |
| **Risk** | "Context anxiety" — model may exit tasks prematurely near limits | None — fresh start eliminates anxiety |
| **Use when** | Mid-task, momentum matters, complexity is moderate | Long-running tasks, high-risk next steps, context > 60% |

Context anxiety: as the model approaches perceived token limits, it tends to declare completion prematurely. Context Reset eliminates this failure mode entirely.

**Other techniques:**

| Technique | When |
|-----------|------|
| Read specs on demand | Never load all `docs/` upfront — read only when needed |
| Subagent for expensive ops | Searches, analysis, large file reads — results summarised before returning to parent |
| `TaskCreate` / `TaskUpdate` | Track in-session progress so state survives a reset |
| Memobank | Persist decisions across sessions |

---

## 5. UI/UX Quality Standards & Harness

### DESIGN.md — UI Harness Anchor

`DESIGN.md` lives at the project root alongside `CLAUDE.md`. It is the single plain-text file describing the product's visual language in a format AI agents can act on directly. It is **read by Claude before any UI work begins** — it is the UI equivalent of CLAUDE.md.

Reference: https://github.com/VoltAgent/awesome-claude-design

**Nine required sections:**

| Section | Content |
|---------|---------|
| Visual Theme & Atmosphere | mood, density, design language (e.g. "craft studio, dark, tactile") |
| Color Palette & Roles | semantic CSS variables with hex values — primary, surface, border, text, destructive |
| Typography Rules | font families, type scale (xs→4xl), line-height, weight usage |
| Component Stylings | buttons, inputs, cards, badges — all states (default, hover, active, disabled, error) |
| Layout Principles | spacing scale, whitespace rhythm, grid system |
| Depth & Elevation | shadow tokens, surface hierarchy (z-index scale) |
| Do's and Don'ts | explicit guardrails — what looks on-brand vs off-brand |
| Responsive Behavior | breakpoints, mobile-first rules, interaction adaptations |
| Agent Prompt Guide | reusable prompt snippets for consistent AI generation |

**DESIGN.md must be committed before any UI feature work begins.** It is updated when the visual language evolves, not per-component.

`tailwind.config.ts` is the **code implementation** of DESIGN.md — color tokens defined in DESIGN.md are mirrored as Tailwind custom colors. DESIGN.md is the source; `tailwind.config.ts` is the output.

### Design System — Tailwind as Code Implementation

- All colors, spacing, and typography from `tailwind.config.ts` — no hardcoded hex values, no magic numbers
- Token names in `tailwind.config.ts` match semantic names in DESIGN.md (`brand-primary`, `surface-elevated`, etc.)
- No inline `style={{}}` — Tailwind classes only
- Custom tokens added to `tailwind.config.ts` from DESIGN.md, never as one-off CSS

### Component Discipline

- **shadcn/ui first** — if shadcn covers it, use it; never reimplement Button, Input, Dialog, Table, etc.
- Custom components only for domain-specific UI: `ZoneShapeUtil`, `CardThumbnail`, `AssetPicker`, etc.
- No per-component CSS files — Tailwind classes only
- All component props have typed interfaces; no `any`

### Accessibility Baseline (M1)

| Rule | Minimum |
|------|---------|
| Interactive elements without visible label | `aria-label` required |
| Keyboard navigation | all interactive elements reachable via Tab |
| Color contrast | WCAG AA — 4.5:1 for body text, 3:1 for large text |
| Focus indicators | never `outline: none` without a visible replacement |

### Anti-Patterns (enforced via `frontend-design` skill)

- No generic AI aesthetics — no default gray cards with no hierarchy, no boring placeholder layouts
- No bare unstyled HTML elements where shadcn components exist
- No `TODO: style this later` components shipped as done
- No layout that only looks right at one viewport width

### Harness Engineering for UI

**Skill gate — `frontend-design:frontend-design` is required before:**
- Building any new page
- Building any new component that is user-facing
- Significantly modifying existing UI

This skill produces distinctive, production-grade UI and actively avoids generic AI aesthetics. It reads `DESIGN.md` as its primary context. It is not optional for M1 — every screen a user sees must go through it.

**Visual verification gate — before any UI task is marked done:**
1. Start dev server (`npm run dev`)
2. Open feature in browser
3. Check golden path (happy state, filled data)
4. Check empty state (no data, first-time user)
5. Check error state (invalid input, failed request)
6. Check that adjacent UI has not regressed

This is part of `verification-before-completion`. A task is not done if it has not been seen in a running browser.

**Browser tooling:**
- Use `mcp__claude-in-chrome__*` tools for visual verification when available
- Read console for client-side errors after every UI change (`mcp__claude-in-chrome__read_console_messages`)
- Never claim "looks good" based on code review alone

**Updated skills workflow gates table** (replaces §4 table):

| Action | Required skill |
|--------|---------------|
| New feature / component / behavior | `brainstorming` |
| Any new page or user-facing component | `frontend-design:frontend-design` |
| Any implementation | `writing-plans` |
| Task > ~1 hour / autonomous multi-step work | `goalbuddy` (`/goal-prep` then `/goal`) |
| Claiming work complete | `verification-before-completion` |
| Debugging a failure | `systematic-debugging` |
| New feature branch | `using-git-worktrees` |
| Code review / KISS audit | `andrej-karpathy-skills:karpathy-guidelines` |

---

## 6. Required Artifacts Before First Feature

These files must exist and be committed before any M1 feature work starts:

| Artifact | Purpose |
|----------|---------|
| `DESIGN.md` | Visual language harness — 9 sections, defines brand tokens |
| `tailwind.config.ts` | Code implementation of DESIGN.md tokens |
| `init.sh` | Environment health check — run at start of every session |
| `.claude/settings.json` | Hooks + permission allowlist |
| `.github/workflows/ci.yml` | CI build gate |
| `.husky/pre-commit` + `.lintstagedrc.json` | Pre-commit gates |
| `prettier.config.js` | Format source of truth |
| `.env.example` | All required env vars documented |
| GoalBuddy (`npx goalbuddy`) | Goal board tool — installs `/goal-prep` skill; run once before first complex task |

---

## 7. Out of Scope (M1)

- `commitlint` or automated commit message linting — enforced by convention, not tooling
- Automated CHANGELOG generation — no public release in M1
- E2E tests (Playwright for UI) — M5
- Full test CI job — added as tests are written
- Branch protection rules on GitHub — solo dev, no team enforcement needed yet
